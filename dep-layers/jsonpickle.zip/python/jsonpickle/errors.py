"""
Stores custom jsonpickle errors.
"""


class ClassNotFoundError(BaseException):
    def __init__(*args, **kwargs):
        pass
